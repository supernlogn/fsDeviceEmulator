#ifndef S25FL_IO_H
#define S25FL_IO_H
/**
 * @file This file contains the basic structures and rules for the IO between the STM32F37 and the S25FL256S
 * The exact model of the flash is the S25FL256SAIF0I62700 ... just go see the board, its next to you probably...
 * If you want really to contribute to the s25fl_io system, please read the FLASH documentation first:
 * http://www.cypress.com/file/177966
 */
#include "s25fl_conf.h"
#include <generic_queue.h>
#include <stm32f4xx_hal.h>
#include <cmsis_os.h>
#include <integer.h>
#include <string.h>


typedef BYTE DSTATUS; // status returned from functions

/**
 * This contains the different registers choices
 * for reading/writting inside the S25FL flashes.
 * Read the manual for more detailed information.
 */
typedef enum
{
	s25fl_SR1 = 0,
	s25fl_SR2 = 1,
	s25fl_CR = 2,
	s25fl_BR = 3,
	s25fl_ECC = 4,
	s25fl_ASP = 5,
	s25fl_AB = 6,
	s25fl_ID = 7,
	s25fl_EMS = 8,
	s25fl_ES = 9,
	s25fl_DLP = 10
} s25fl_reg_t;
/**
 * @brief This contains the different states of the spi FSM.
 * @note This FSM runs only when SPI-DMA interrupts
 * 		 are called.
 */
typedef enum
{
	S25FL_HANDLE_USER_TX = 0,
	S25FL_HANDLE_USER_RX = 1,
	S25FL_HANDLE_FLASH_PRG_ER_CMD_DATA = 2,
	S25FL_CHECK_FLASH_PRG_ER_CHECK = 3,
	S25FL_HANDLE_CMD_DATA = 4,
	S25FL_CHECK = 5,
	S25FL_DONE = 6,
	S25FL_ERROR_STATUS = 7,
}s25fl_msg_status_t;
/* */

/**
 * @brief A default data type for the FLASH registers.
 * @note They can also be bigger.
 */
typedef uint8_t s25fl_reg_val_t;
/**
 * @brief This is a general structure which can hold all the register data.
 * @note  It can also be used as a reference for how much data each FLASH register
 * 		  requires.
 */
typedef struct s25fl_status_t // TODO: Needs packing
{
	uint32_t ID;
	uint8_t ES;
	uint16_t EMS;
	s25fl_reg_val_t SR1;
	s25fl_reg_val_t SR2;
	s25fl_reg_val_t CR;
	s25fl_reg_val_t ECC;
	s25fl_reg_val_t BR;
	uint16_t ASP;
	uint32_t AB;
	uint16_t DLP;
	uint8_t OTP[1024];
} s25fl_status_t;


/**
 * This is the typical structure of a small command
 * which is read by the FSM.
 */
typedef struct
{
	uint32_t writecnt;
	uint32_t readcnt;
	uint8_t *writearr;
	uint8_t *readarr;
}spi_msg_t;

/**
 * struct to handle the user data
 */
typedef struct
{
	uint32_t buffer_cnt;
	uint8_t * buffer;
	uint32_t auxiliary_buffer_cnt;
	uint8_t * auxiliary_buffer;
} user_data_t;

typedef enum
{
	dev_25fl_0 = 0,
	dev_25fl_1 = 1,
	dev_none = 2
}dev_id_t;

#ifdef ASYNC_SUPPORT
/**
 * This is the message which the FSM has to handle
 * at each SPI-DMA interrupt.
 * It can define write/read a single command
 * or write a larger command for writting/reading
 * large buffers from/to FLASH.
 * TODO: needs packing
 */
typedef struct s25fl_msg_t
{
	user_data_t user_data;
	spi_msg_t sys_command;
	uint32_t d_val;
	uint32_t mask;

	s25fl_msg_status_t status;
	s25fl_msg_status_t init_status;
}s25fl_msg_t;




#endif
/**
 * This is the class which handles the IO of the 2 s25fl devices.
 * For the asynchronous case it uses the proactor pattern: http://www.boost.org/doc/libs/1_47_0/doc/html/boost_asio/overview/core/async.html
 */
struct s25fl_io_t
{	uint8_t initialized;
	dev_id_t device_id;
	SPI_HandleTypeDef * hspi;
	/**
	 * This is the queue which holds pending requests to flash.
	 * at each SPI-DMA interrupt the FSM tries to handle one pending request
	 * if the queue is not empty.
	 */
	pqueue_t queue;
	DSTATUS (*init) (struct s25fl_io_t* self, SPI_HandleTypeDef *hspi, GPIO_TypeDef * gpio_port, uint16_t gpio_pin, dev_id_t device_id, pqueue_t queue);
	DSTATUS (*reset) (const struct s25fl_io_t* self);
	DSTATUS (*enable) (const struct s25fl_io_t* self);
	DSTATUS (*disable) (const struct s25fl_io_t* self);
	DSTATUS (*get_status) (const struct s25fl_io_t* self, s25fl_status_t * s25fl_status);
	DSTATUS (*write_data) (struct s25fl_io_t* self, const uint32_t start_address, const BYTE * data, const uint16_t els_size);
	DSTATUS (*read_data) (const struct s25fl_io_t* self, const uint32_t start_address, BYTE * data, const uint16_t els_size);
	DSTATUS (*erase_data) (const struct s25fl_io_t* self, const uint32_t start_address);
	DSTATUS (*read_register) (const struct s25fl_io_t* self, const s25fl_reg_t reg, s25fl_reg_val_t* reg_val);
	DSTATUS (*write_register) (const struct s25fl_io_t* self, const s25fl_reg_t reg, const s25fl_reg_val_t reg_val);
	DSTATUS (*wait_till_ready) (const struct s25fl_io_t* self, const uint16_t timeout);

#ifdef ASYNC_SUPPORT
	GPIO_TypeDef * gpio_port;
	uint16_t gpio_pin;
	/* Whether to force synchronous operations.
	 * if set to != 0 all reads and writes become synchronous
	 * if set to 0, the asynchronous parts of data transactions remain asynchronous.
	 */
	uint8_t force_synchronous;

	DSTATUS (*reset_status) (const struct s25fl_io_t * self);
#endif
};

typedef struct s25fl_io_t s25fl_io_t;

DSTATUS s25fl_link_create(s25fl_io_t * s25fl_io, SPI_HandleTypeDef *hspi, GPIO_TypeDef * gpio_port, uint16_t gpio_pin, dev_id_t device_id, pqueue_t queue);

#ifdef ASYNC_SUPPORT

extern pqueue_t s25fl_queue;
extern uint16_t last_action;

/* memory to fetch data for s25fl_msg_t buffers */
extern uint8_t command_pool[];
/* use command pool:*/
#define get_command_buf_start(cmd) (cmd * COMMAND_POOL_SIZE / S25FL_MAX_Q_SIZE )
/* use command pool:*/
#define get_command_buf_start_write(cmd) (cmd * COMMAND_POOL_SIZE / S25FL_MAX_Q_SIZE )
/* use command pool:*/
#define get_command_buf_start_read(cmd) (cmd * COMMAND_POOL_SIZE / S25FL_MAX_Q_SIZE + COMMAND_POOL_SIZE / (2 * S25FL_MAX_Q_SIZE))

void s25fl_msg_free_func(elem_addr_t addr);

void SPI_DMA_IRQ_Packet_Handler(s25fl_io_t *s25fl_io);
#endif

#endif
