/************************************************************************
 * 
 * File name:		generic-queue.c
 * Description:		Generic Queue's Implementation
 * Author:		dennis_fan(dennis_fan@outlook.com), 2013/2/26
 * 				implementation for embedded systems by Ioannis Athanasiadis(i.athanasiadis@kenotom.com)
 * Version:		1.1
 *************************************************************************/

#include <generic_queue.h>
#include <stdlib.h>
#include <string.h>
#include <cmsis_os.h>

#define MAX_QUEUE_SIZE (64)



/* private member declarations */
static inline int _successor(pqueue_t que, int index);

static inline int _successor(pqueue_t que, int index)
{
	++index;
	index %= que->capacity;
	return index;
}



/* Create a new queue with capacity */
queue_status_t queue_init(pqueue_t que, size_t elemsize, int capacity, PfCbFree freefn, const elem_addr_t buffer)
{

	if ( que == NULL )
	{
		return INVALID_QUEUE_POINTER;
	}
	
	que->elemsize = elemsize;

	if(capacity < MAX_QUEUE_SIZE)
	{
		que->capacity = capacity;
	}
	else
	{
		que->capacity = MAX_QUEUE_SIZE;
	}

	que->array = buffer;
	if ( que->array == NULL )
	{
		return INVALID_QUEUE_BUFFER_POINTER;
	}
	que->front = 1;
	que->rear = 0;
	que->size = 0;
	que->freefn = freefn;


	return QUEUE_OK;
}

/* Dispose the queue */
void queue_dispose(pqueue_t que)
{
	if (que != NULL)
	{
		queue_make_empty(que);
	}
}

/* Make the give queue empty */
void queue_make_empty(pqueue_t que)
{
	if ( que->freefn )
	{
		int i;
		for ( i = 0; i < que->size; ++i)
		{
			que->freefn( que->array + i );
		}
	}
	que->size = 0;
	que->front = 1;
	que->rear = 0;
}

/* Return true if the queue is empty */
int queue_is_empty(pqueue_t que)
{
	return (que->size == 0);
}

/* Return true if the queue is full */
int queue_is_full(pqueue_t que)
{
	return (que->size == que->capacity);
}



/* Insert a new element onto queue(rear) */
queue_status_t queue_enqueue(pqueue_t que, elem_addr_t elemaddr)
{
	void *target;

	if ( queue_is_full(que) )
	{
		return QUEUE_ERROR_FULL;
	}

	que->rear = _successor(que, que->rear);
	target = (char *)que->array + que->elemsize * que->rear;
	memcpy(target, elemaddr, que->elemsize);
	que->size++;

	return QUEUE_OK;
}

/* Delete the front element off the queue */
queue_status_t queue_dequeue(pqueue_t que)
{
	if ( queue_is_empty(que) )
	{
		return QUEUE_ERROR_EMPTY;
	}

	if ( que->freefn )
	{
		void *target = (char *)que->array + que->front * que->elemsize;
		que->freefn(target);
	}

	que->size--;
	que->front = _successor(que, que->front);

	return QUEUE_OK;
}

/* Fetch the front element from the queue, with shallow copy */
#ifdef SHALLOW_COPY
queue_status_t queue_front(pqueue_t que, elem_addr_t * elemaddr)
#else
queue_status_t queue_front(pqueue_t que, elem_addr_t elemaddr)
#endif
{
	void *target = (char *)que->array + que->front * que->elemsize;
#ifdef SHALLOW_COPY
   *elemaddr = target;
#else
	memcpy(elemaddr, target, que->elemsize);
#endif



	return QUEUE_OK;
}

/* Fetch and Delete the front element from the queue */
#ifdef SHALLOW_COPY
queue_status_t queue_front_and_dequeue(pqueue_t que, elem_addr_t *elemaddr)
#else
queue_status_t queue_front_and_dequeue(pqueue_t que, elem_addr_t elemaddr)
#endif

{
	void *target;

	if ( queue_is_empty(que) )
	{
		return QUEUE_ERROR_EMPTY;
	}

	target = (char *)que->array + 
                       que->front * que->elemsize;

#ifdef SHALLOW_COPY
	*elemaddr = target;
#else
	memcpy(elemaddr, target, que->elemsize);
#endif


	que->size--;
	que->front = _successor(que, que->front);

	return QUEUE_OK;
}

/* wait until the queue is empty */
queue_status_t queue_wait (const pqueue_t que, const uint32_t timeout)
{
	uint32_t t = 0;

	while(!queue_is_empty(que))
	{
		osDelay(10); // check every 10 ms if the queue has finish its job
		t += 10;
	}

	if(t < timeout)
	{
		return QUEUE_OK;
	}
	else
	{
		return QUEUE_ERROR_TIMEOUT;
	}
}


