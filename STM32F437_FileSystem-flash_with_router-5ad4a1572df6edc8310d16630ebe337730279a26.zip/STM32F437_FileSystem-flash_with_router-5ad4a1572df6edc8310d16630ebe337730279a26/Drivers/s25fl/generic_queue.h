/************************************************************************
 * 
 * File name:		generic-queue.h
 * Description:		Queue's API
 * Author:		dennis_fan(dennis_fan@outlook.com), 2013/2/26
 * 				implementation for embedded systems by Ioannis Athanasiadis(i.athanasiadis@kenotom.com)
 * Version:		1.1
 *************************************************************************/

#ifndef _GENERIC_QUEUE_H
#define _GENERIC_QUEUE_H
/* define shallow copy if you want copy to be shallow at fetching elements */
#define SHALLOW_COPY 1
#include <stddef.h>
#include <stdint.h>


typedef void *elem_addr_t;
typedef void (*PfCbFree)(elem_addr_t);

typedef enum
{
	QUEUE_OK = 0,
	INVALID_QUEUE_POINTER = 1,
	INVALID_QUEUE_BUFFER_POINTER = 2,
	QUEUE_ERROR_FULL = 3,
	QUEUE_ERROR_EMPTY = 4,
	QUEUE_ERROR_TIMEOUT = 5,
}queue_status_t;

typedef struct queue_t
{
	elem_addr_t	array;
	uint16_t	capacity;
	size_t		elemsize;
	int			front;
	int			rear;
	uint16_t	size;
	PfCbFree	freefn;
} queue_t;

typedef queue_t * pqueue_t;

/* Create a new queue */
queue_status_t queue_init(pqueue_t que, size_t elemsize, int capacity, PfCbFree freefn, const elem_addr_t buffer);

/* Dispose the queue */
void queue_dispose(pqueue_t que);

/* Make the give queue empty */
void queue_make_empty(pqueue_t que);

/* Return true if the queue is empty */
int queue_is_empty(pqueue_t que);

/* Return true if the queue is full */
int queue_is_full(pqueue_t que);

/* Insert a new element onto queue */
queue_status_t queue_enqueue(pqueue_t que, elem_addr_t elemaddr);

/* Delete the front element off the queue */
queue_status_t queue_dequeue(pqueue_t que);

/* Fetch the front element from the queue */
#ifdef SHALLOW_COPY
queue_status_t queue_front(pqueue_t que, elem_addr_t * elemaddr);
#else
queue_status_t queue_front(pqueue_t que, elem_addr_t elemaddr);
#endif

/* Fetch and Delete the front element from the queue */
#ifdef SHALLOW_COPY
queue_status_t queue_front_and_dequeue(pqueue_t que, elem_addr_t *elemaddr);
#else
queue_status_t queue_front_and_dequeue(pqueue_t que, elem_addr_t elemaddr);
#endif
/* Wait until some FSM processes all the queue */
queue_status_t queue_wait (const pqueue_t que, const uint32_t timeout);

#endif /* THE END */

