/*
 * s25fl_router.c
 *
 *  Created on: 28 ���� 2017
 *      Author: ath.io
 */


#include "s25fl_router.h"


static DSTATUS s25fl_router_select_device(s25fl_router_t *self, dev_id_t dev_id_num)
{
	DSTATUS res = HAL_OK;

	if(dev_id_num >= MAX_NUM_FLASHES && !(dev_id_num == dev_none))
	{
		res = 0xFF;
		return res;
	}

	if(self->active_device != dev_none)
	{
		/* close the already active device */
		//wait to finish
		s25fl_io_t * s25fl = self->s25fl_ios[self->active_device];
		res = s25fl->wait_till_ready(s25fl, osWaitForever);
		//close
		s25fl->disable(s25fl);
	}
	self->active_device = dev_id_num;

	if(dev_id_num != dev_none)
	{
		s25fl_io = self->s25fl_ios[self->active_device];
	}
	else
	{
		s25fl_io = NULL;
	}

	return res;
}


static DSTATUS s25fl_router_register_device(s25fl_router_t *self, s25fl_io_t *s25fl_io)
{
	DSTATUS res = HAL_OK;

	if(s25fl_io == NULL)
	{
		res = 0xFF;
		return res;
	}

	if(s25fl_io->device_id < self->num_devs)
	{
		res = 0x0F;
		return res;
	}

	if(self->num_devs < MAX_NUM_FLASHES)
	{
		self->s25fl_ios[self->num_devs] = s25fl_io;
		self->num_devs++;
	}
	else
	{
		res = 0xF0;
	}

	return res;
}

static DSTATUS s25fl_router_remove_device(s25fl_router_t *self, dev_t dev_id)
{
	DSTATUS res = HAL_OK;
	if(self->num_devs < dev_id )
	{
		res = 0xFF;
		return res; // error
	}

	/* assign the last device to this device's cell */
	// wait if it is busy
	if(self->active_device == self->num_devs - 1)
	{
		s25fl_io_t *s25fl = self->s25fl_ios[self->active_device];
		s25fl->wait_till_ready(s25fl, osWaitForever);
		self->active_device = dev_id; // take care to be active before swap
	}

	// assign it
	self->s25fl_ios[dev_id] = self->s25fl_ios[self->num_devs - 1];

	self->num_devs--;

	return res;
}

DSTATUS s25fl_router_link_create(s25fl_router_t* s25fl_router, pqueue_t device_queue)
{
	DSTATUS res = HAL_OK;

	if(s25fl_router == NULL || device_queue == NULL)
	{
		res = 0xF0;
		return res;
	}

	if(s25fl_router->is_initialized != 0xAA)
	{
		// link
		s25fl_router->register_device = s25fl_router_register_device;
		s25fl_router->remove_device = s25fl_router_remove_device;
		s25fl_router->select_device = s25fl_router_select_device;
		// create
		s25fl_router->active_device = dev_none;
		s25fl_router->num_devs = 0;
		s25fl_router->device_queue = device_queue;
		s25fl_router->is_initialized = 0xAA;
	}
	return res;
}
