/*
 * s25fl_io_async.c
 *
 *  Created on: 15 ��� 2017
 *      Author: ath.io
 */
#include "s25fl_io.h"
#include "s25fl_cmd.h"
#include "boot_data.h"
#ifdef ASYNC_SUPPORT



#define MAX_WRITE_SIZE 256U
uint16_t last_action = 0;
#define ACTION_WRITE 1
#define ACTION_READ 2
#define ACTION_ERASE 3
#define ACTION_FULL_ERASE 4
/**
 * a command to invoke the SPI IRQ handler
 */
#define mini_dma_command()\
	if(HAL_SPI_GetState(self->hspi) == HAL_SPI_STATE_READY)\
    {\
		HAL_SPI_Transmit_DMA(self->hspi, mini_dma_command_zero_data, sizeof(mini_dma_command_zero_data));\
    }

static const uint8_t mini_dma_command_zero_data[] = {0, 0, 0, 0};

/*
 * A macro to determine only sys_command values of a
 * new s25fl_msg_t struct and make it appropriate to
 * send only commands.
 */
#define simple_cmd_s(cmd_name, s_mask, s_d_val)\
{\
	.sys_command = {\
					.writearr = (const uint8_t[]) {cmd_name, 0, 0, 0, 0, 0},\
					.writecnt = cmd_name##_OUTSIZE,\
					.readarr = (const uint8_t[]) {0, 0, 0, 0, 0, 0},\
					.readcnt = cmd_name##_INSIZE,\
					},\
	.user_data = {\
				.buffer = NULL,\
				.buffer_cnt = 0, \
				.auxiliary_buffer = NULL,\
				.auxiliary_buffer_cnt = 0, \
				},\
	.status = S25FL_HANDLE_CMD_DATA,\
	.init_status = S25FL_HANDLE_CMD_DATA,\
	.mask = s_mask, \
	.d_val= s_d_val,\
}
/*
  * A macro to determine only sys_command values of an
 *  existing s25fl_msg_t struct and make it appropriate to
 *  send only commands.
 */
#define simple_cmd_c(cmd_name, s_mask, s_d_val, buffer_to_read, spi_msg)\
	spi_msg.user_data.buffer = NULL;\
	spi_msg.user_data.buffer_cnt = 0; \
	spi_msg.user_data.auxiliary_buffer = NULL;\
	spi_msg.user_data.auxiliary_buffer_cnt = 0; \
	\
	spi_msg.sys_command.writearr = (const uint8_t[]) {cmd_name, 0, 0, 0, 0, 0};\
	spi_msg.sys_command.writecnt = cmd_name##_OUTSIZE;\
	spi_msg.sys_command.readarr = buffer_to_read;\
	spi_msg.sys_command.readcnt = cmd_name##_INSIZE;\
\
	spi_msg.status = S25FL_HANDLE_CMD_DATA;\
	spi_msg.init_status = S25FL_HANDLE_CMD_DATA;\
	spi_msg.mask = s_mask; \
	spi_msg.d_val= s_d_val;

/*
 * A macro to determine all values of a
 * new s25fl_msg_t struct
 */

#define full_command_s(buf_cmd_w0, buf_cmd_wcnt0, buf_cmd_r0, buf_cmd_rcnt0, user_data0, user_data_cnt0, auxiliary_buffer0, auxiliary_buffer_cnt0, init_status0, mask0, d_val0)\
{\
	.user_data = (user_data_t){\
				.buffer = (user_data0),\
				.buffer_cnt = (user_data_cnt0),\
				.auxiliary_buffer = (auxiliary_buffer0),\
				.auxiliary_buffer_cnt = (auxiliary_buffer_cnt0)\
				},\
	.sys_command =  {\
					.writearr = (buf_cmd_w0),\
					.writecnt = (buf_cmd_wcnt0),\
					.readarr = (buf_cmd_r0),\
					.readcnt = (buf_cmd_rcnt0)\
					},\
	.status = (init_status0),\
	.init_status = (init_status0),\
	.mask = (mask0),\
	.d_val = (d_val0)\
}


#ifndef PUT_UINT32_BE
#define PUT_UINT32_BE(n,b,i)                  \
{                                             \
    (b)[(i)    ] =  ( (n) >> 24 ) &0xFFU;     \
    (b)[(i) + 1] =  ( (n) >> 16 ) &0xFFU;     \
    (b)[(i) + 2] =  ( (n) >>  8 ) &0xFFU;     \
    (b)[(i) + 3] =  ( (n)       ) &0xFFU;     \
}
#endif

/* swap two values v1,v2 given a temporary variable t */
#define SWAP_VALUES(v1,v2,t) \
		t = v1;\
		v1 = v2;\
		v2 = t;

/* noteable commands */
const static s25fl_msg_t WRITE_ENABLE = simple_cmd_s(JEDEC_WREN, 0, 0);
const static s25fl_msg_t WRITE_DISABLE = simple_cmd_s(JEDEC_WRDI, 0, 0);
const static s25fl_msg_t WAIT_WIP_BIT = simple_cmd_s(JEDEC_RDSR1, S25FL_SR1_WIP, 0);
const static s25fl_msg_t WAIT_WEL_BIT = simple_cmd_s(JEDEC_RDSR1, S25FL_SR1_WEL, S25FL_SR1_WEL);
const static s25fl_msg_t WAIT_E_ERR_BIT = simple_cmd_s(JEDEC_RDSR1, S25FL_SR1_E_ERR, 0);
const static s25fl_msg_t READ_ID = simple_cmd_s(JEDEC_RDID, 0, 0);
const static s25fl_msg_t WAIT_P_ERR = simple_cmd_s(JEDEC_RDSR1, S25FL_SR1_P_ERR, 0);
const static s25fl_msg_t WAIT_P_E_ERRS = simple_cmd_s(JEDEC_RDSR1, S25FL_SR1_P_ERR | S25FL_SR1_E_ERR | S25FL_SR1_WIP, 0);
const static s25fl_msg_t WRITE_SR_CR_REG = simple_cmd_s(JEDEC_WRR, 0, 0);
const static s25fl_msg_t SW_RESET_CMD =  simple_cmd_s(JEDEC_SW_RESET, 0, 0);
const static s25fl_msg_t CLSR_CMD = simple_cmd_s(JEDEC_CLSR, 0, 0);
const static s25fl_msg_t PLBWR_CMD = simple_cmd_s(JEDEC_PLBWR, 0, 0);

const static s25fl_msg_t ZERO_MSG = {
		.user_data = {
				0
		},
		.sys_command = {
				.writecnt = 32,
				.writearr =(const uint8_t[]){0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
				.readcnt = 0,
				.readarr = NULL,
		},
		.mask = 0,
		.d_val = 0,
		.init_status = S25FL_HANDLE_CMD_DATA,
		.status = S25FL_HANDLE_CMD_DATA
};



const static s25fl_msg_t WRITE_PERFECT_SR_REG =
{
		.user_data = {
				0
		},
		.sys_command = {
				.writecnt = JEDEC_WRR_OUTSIZE,
				.writearr =(const uint8_t[]){JEDEC_WRR, S25FL_SR1_WEL},
				.readcnt = JEDEC_WRR_INSIZE,
				.readarr = NULL,
		},
		.mask = 0,
		.d_val = 0,
		.init_status = S25FL_HANDLE_CMD_DATA,
		.status = S25FL_HANDLE_CMD_DATA
};

/* public member declerations */
static DSTATUS s25fl_write_data (s25fl_io_t* self, const uint32_t start_address, const BYTE * data, const uint16_t els_size);
static DSTATUS s25fl_read_data (const s25fl_io_t* self, const uint32_t start_address, BYTE * data, const uint16_t els_size);
static DSTATUS s25fl_erase_data (const s25fl_io_t* self, const uint32_t start_address);
static DSTATUS s25fl_read_register (const s25fl_io_t* self, const s25fl_reg_t reg, s25fl_reg_val_t * reg_val);
static DSTATUS s25fl_write_register (const s25fl_io_t* self, const s25fl_reg_t reg, const s25fl_reg_val_t reg_val);
static DSTATUS s25fl_io_init_async (s25fl_io_t* self, SPI_HandleTypeDef *hspi, GPIO_TypeDef * gpio_port, uint16_t gpio_pin, dev_id_t device_id, pqueue_t queue);
static DSTATUS s25fl_reset(const s25fl_io_t* self);
static DSTATUS s25fl_get_status(const s25fl_io_t* self, s25fl_status_t * s25fl_status);
static DSTATUS s25fl_reset_status(const struct s25fl_io_t * self);

/* private member declerations */
static DSTATUS _read_OTP (const s25fl_io_t* self, uint8_t * result);
static DSTATUS _erase_all_flash(s25fl_io_t * self);
static DSTATUS _send_command(const s25fl_io_t* self, const s25fl_msg_t * cmd);

/**
 * This function sets the flash cs pin to the specified value
 * @param self
 * @param val the value to set the cs pin
 * @retval HAL_OK
 */
static DSTATUS _set_flash_cs(const s25fl_io_t* self, const GPIO_PinState val)
{
	HAL_GPIO_WritePin(self->gpio_port, self->gpio_pin, val);
	return HAL_OK;
}

/**
 *  @brief enables the current flash chip
 *  @param self
 *  @retval HAL_OK
 */
static inline DSTATUS _enable_s25fl_io(const s25fl_io_t* self)
{
	return _set_flash_cs(self, GPIO_PIN_RESET);
}
/**
 *  @brief disables the current flash chip
 *  @param self
 *  @retval HAL_OK
 */
static inline DSTATUS _disable_s25fl_io(const s25fl_io_t* self)
{
	return _set_flash_cs(self, GPIO_PIN_SET);
}

/**
 * @brief initialize FLASH registers at their RIGHT!! default value!
 * @param self
 * @retval always HAL_OK
 *
 * Enable 4 byte addressing by
 * enabling the ExtAdd bit in BR register
 * Also, disable dummy cycles by
 * setting CL = 0b11
 *
 */
static DSTATUS _init_regs(s25fl_io_t *self)
{
	DSTATUS res = HAL_OK;
	s25fl_reg_val_t reg;
    int t;

	int j = 0; // integer iterator

	uint8_t old_force_synchronous = self->force_synchronous;
	self->force_synchronous = 1;

	t = HAL_GetTick();
	while(HAL_GetTick() - t < S25FL_LARGE_TIMEOUT)
	{
	  self->read_register(self, s25fl_SR1, &reg);
	}

	/* set bank register to allow 32-bit addresses */
	self->read_register(self, s25fl_BR, &reg);
	reg |= S25FL_BR_EXTADD;
	self->write_register(self, s25fl_BR, reg);

	/* set configuration register */
	self->read_register(self, s25fl_CR, &reg);
	reg |= (S25FL_CR1_LC0 | S25FL_CR1_LC1 | S25FL_CR1_BPNV);
	reg &= ~S25FL_CR1_FREEZE;
	self->write_register(self, s25fl_CR, reg);

	/* clear status register */
	_send_command(self, &CLSR_CMD);

	/* set protection bits in status register, try doing it 3 times */

	for(j = 2; j >= 0; --j)
	{
	  while(HAL_GetTick() - t < S25FL_TIMEOUT)
	  {
		self->read_register(self, s25fl_SR1, &reg);
	  }

	  self->write_register(self, s25fl_SR1, S25FL_SR1_WEL);
	}
	self->force_synchronous = old_force_synchronous;

	return res;
}


/**
 * @brief initializes the hardware needed for
 * communicating with the two FLASH chips.
 * Default selection is device 0.
 * @param self
 * @param hspi the already initialized spi handler structure
 * @returns HAL_OK
 */
static DSTATUS s25fl_io_init_async (s25fl_io_t* self, SPI_HandleTypeDef *hspi, GPIO_TypeDef * gpio_port, uint16_t gpio_pin, dev_id_t device_id, pqueue_t queue)
{
	DSTATUS res = HAL_OK;
    if(!(self->initialized))
    {
    	self->device_id = device_id; // default selected device

    	self->hspi = hspi;

		self->gpio_port = gpio_port;
		self->gpio_pin = gpio_pin;

		/* initialize GPIOS */
		GPIO_InitTypeDef gpio_init;
		gpio_init.Pull = GPIO_NOPULL;
		gpio_init.Mode = GPIO_MODE_OUTPUT_PP;
		gpio_init.Speed = GPIO_SPEED_FREQ_LOW;
		gpio_init.Pin = gpio_pin;
		HAL_GPIO_Init(gpio_port, &gpio_init);

		/* initialize the asynchronous queue */
		if(queue == NULL)
		{
			res = 0xFF;
			return res;
		}

		self->queue = queue;

		self->disable(self);

		__HAL_RCC_SPI4_CLK_ENABLE();
		__HAL_SPI_ENABLE(self->hspi);

		/* set register to their desired value */
		_init_regs(self);



		/* reinitialize channel */
		HAL_Delay(S25FL_TIMEOUT);

		#ifdef HANDLE_FIRST_BOOT
			/* if this is the first time this software boots */
		    if(FLASH_NEEDS_CLEANING(self->device_id))
		    {
		    	_erase_all_flash(self);
//		    	RESET_FLASH_NEEDS_CLEANING(self->device_id); TODO: Cannot change value to flash page this way
		    }
		#endif
		self->initialized = 1;
    }

    return res;
}

/**
 * @brief restart the currently selected FLASH.
 * @param self
 * @retval HAL_OK if the device chosen was one of the 2, else 0xFF
 */
static DSTATUS s25fl_reset(const s25fl_io_t* self)
{

    DSTATUS res = HAL_OK;

    if(self->device_id != dev_none)
    {
		self->disable(self);
		//HAL_Delay(S25FL_TIMEOUT); //TODO: Ok @RCC_HCLK_DIV2
    }
    else
    {
    	res = 0xFF;
    }

    self->enable(self);
    HAL_SPI_Transmit(self->hspi, SW_RESET_CMD.sys_command.writearr, SW_RESET_CMD.sys_command.writecnt, 100U);
    self->disable(self);

	s25fl_reset_status(self);

    return res;
}

/**
 * @brief write data to the selected FLASH chip.
 * Non-blocking operation
 * @param self
 * @param start_address Address inside a flash chip, not the one used inside the file system.
 * @param data Data to write inside FLASH chip
 * @param els_size size of data buffer in bytes. Must be <= 512U
 * @returns if writing data was sucessfull
 *   HAL_OK when all were good.
 */
DSTATUS s25fl_write_data (s25fl_io_t* self, const uint32_t start_address, const BYTE * data, const uint16_t els_size)
{
	last_action = ACTION_WRITE;
    DSTATUS res = HAL_OK;
    int cmd = (self->queue->rear + 3)% S25FL_MAX_Q_SIZE;
    int i;

    if(els_size > MAX_WRITE_SIZE)
    {
		res = 0xF0;
		return res;
    }

    uint8_t queue_state = queue_is_empty(self->queue);

    uint8_t * command_buffer = &command_pool[get_command_buf_start(cmd)];
    command_buffer[0] = JEDEC_BYTE_PROGRAM;
	PUT_UINT32_BE(start_address, command_buffer, 1);

	const s25fl_msg_t cmds[] = {
    	CLSR_CMD,
		WAIT_WIP_BIT,
		/* send enable write command */
		 WRITE_ENABLE,
		/* wait for WEL in SR1 to verify that write is enabled */
		 WAIT_WEL_BIT,
		 PLBWR_CMD,
		/* wait for other operations which are in progress */
		 WAIT_WIP_BIT,
		 WRITE_ENABLE,
		/* wait for WEL in SR1 to verify that write is enabled */
		 WAIT_WEL_BIT,
		/* send programming command & send data to write */
		 full_command_s(WAIT_P_E_ERRS.sys_command.writearr, WAIT_P_E_ERRS.sys_command.writecnt, WAIT_P_E_ERRS.sys_command.readarr, WAIT_P_E_ERRS.sys_command.readcnt, data, els_size,\
		 				command_buffer, JEDEC_BYTE_PROGRAM_OUTSIZE, S25FL_HANDLE_USER_TX, WAIT_P_E_ERRS.mask, WAIT_P_E_ERRS.d_val),
		/* check WIP(0 = programming succeeded) and P_ERR(1 = if there were errors) in SR1 */
		WAIT_WIP_BIT,
		WRITE_PERFECT_SR_REG,
		/* send write disable command */
		 WRITE_DISABLE,
    };

    for(i = 0; i < sizeof(cmds)/sizeof(cmds[0]); ++i)
    {
    	res |= queue_enqueue(self->queue, &cmds[i]);
    }

    if(queue_state || self->hspi->State == HAL_SPI_STATE_READY)
    {
    	mini_dma_command();
    }

    if(self->force_synchronous)
    {
    	res |= queue_wait(self->queue, osWaitForever);
    }

    return res;
}
/**
 * This function reads data from the selected FLASH chip to a buffer in RAM.
 * Non-blocking operation
 * @param self
 * @param start_address Address inside a flash chip, not the one used inside the file system.
 * @param data Databuffer to be filled with data from inside the FLASH chip
 * @param els_size size of data buffer in bytes
 * @returns if reading data was sucessfull
 *   HAL_OK when all were good.
 */
static DSTATUS s25fl_read_data (const s25fl_io_t* self, const uint32_t start_address, BYTE * data, const uint16_t els_size)
{
	last_action = ACTION_READ;
    DSTATUS res = 0x00;

    int cmd = (self->queue->rear + 4) % S25FL_MAX_Q_SIZE;
    int i;
    uint8_t queue_state = queue_is_empty(self->queue);

    uint8_t * command_buffer = &command_pool[get_command_buf_start(cmd)];
	command_buffer[0] = JEDEC_READ;
	PUT_UINT32_BE(start_address, command_buffer, 1);

    const s25fl_msg_t cmds[] = {
    CLSR_CMD,
	/* wait for other operations which are in progress */
	WAIT_WIP_BIT,
	/* send a FAST READ command followed by the address & read the data */
	full_command_s(NULL, 0, NULL, 0, data, els_size, command_buffer, JEDEC_READ_OUTSIZE, S25FL_HANDLE_USER_RX, 0x00, 0),
    };

    for( i = 0; i < sizeof(cmds)/sizeof(cmds[0]); ++i)
    {
    	res |= queue_enqueue(self->queue, &cmds[i]);
    }

    if(queue_state || self->hspi->State == HAL_SPI_STATE_READY)
    {
    	mini_dma_command();
    }

    if(self->force_synchronous)
    {
    	res |= queue_wait(self->queue, osWaitForever);
    }
    return res;
}
/**
 * Erase FLASH per 4kB (previously 64 kB).
 * @param self
 * @param start_address starting address from where to start erasing data.
 * @param els_size size of erase part
 * @return whether erase command was sent.
 *   HAL_OK when all were good.
 */
static DSTATUS s25fl_erase_data (const s25fl_io_t* self, const uint32_t start_address)
{
	last_action = ACTION_ERASE;
    DSTATUS res = 0x00;

    int cmd = (self->queue->rear + 4) % S25FL_MAX_Q_SIZE;
    int i;
    uint8_t queue_state = queue_is_empty(self->queue);

    uint8_t * command_buffer = &command_pool[get_command_buf_start(cmd)];
	command_buffer[0] = JEDEC_BE_DC;
	PUT_UINT32_BE(start_address, command_buffer, 1);

    const s25fl_msg_t cmds[] = {
		CLSR_CMD,
		WAIT_WIP_BIT,
		/* send enable write command */
		 WRITE_ENABLE,
		/* wait for WEL in SR1 to verify that write is enabled */
		 WAIT_WEL_BIT,
		 PLBWR_CMD,
		/* wait for other operations which are in progress */
		 WAIT_WIP_BIT,
		 WRITE_ENABLE,
		/* wait for WEL in SR1 to verify that write is enabled */
		 WAIT_WEL_BIT,
		 ZERO_MSG,
		/* send erase sector command */
		full_command_s(WAIT_E_ERR_BIT.sys_command.writearr, WAIT_E_ERR_BIT.sys_command.writecnt, WAIT_E_ERR_BIT.sys_command.readarr, WAIT_E_ERR_BIT.sys_command.readcnt,\
						command_buffer, JEDEC_BE_DC_OUTSIZE, NULL, 0, S25FL_HANDLE_USER_TX, WAIT_E_ERR_BIT.mask, WAIT_E_ERR_BIT.d_val),
//		 ZERO_MSG,
		/* check WIP(0 = programming succeeded) and P_ERR(1 = if there were errors) in SR1 */
		WAIT_WIP_BIT,
		WRITE_PERFECT_SR_REG,
//		 ZERO_MSG,
		/* send write disable command */
		 WRITE_DISABLE,
//		 ZERO_MSG,
    };

    for( i = 0; i < sizeof(cmds)/sizeof(cmds[0]); ++i)
    {
    	res |= queue_enqueue(self->queue, &cmds[i]);
    }

    if(queue_state || self->hspi->State == HAL_SPI_STATE_READY)
    {
    	mini_dma_command();
    }

    if(self->force_synchronous)
    {
    	res |= queue_wait(self->queue, osWaitForever);
    }
    return res;
}
/**
 * Send a command to FLASH chip. This command can return data or not. If not
 * then `cmd->readcnt` should be `0`.
 * @param self
 * @param cmd command to set.
 * @ returns if the command was send successfully
 *   HAL_OK when all were good.
 */
static DSTATUS _send_command(const s25fl_io_t* self, const s25fl_msg_t * cmd)
{
    HAL_StatusTypeDef res = 0;

    uint8_t queue_state = queue_is_empty(self->queue);

	res |= queue_enqueue(self->queue, cmd);

	if(queue_state || ( (self->hspi->State == HAL_SPI_STATE_READY) && !res ))
    {
    	mini_dma_command();
    }

	if(self->force_synchronous)
	{
		res |= queue_wait(self->queue, osWaitForever);
	}

    return res;
}

/**
 * #brief reads a register of the selected FLASH chip.
 * @param self
 * @param reg register to read.
 * @param reg_val buffer to where to put value of the register.
 * @returns whether reading the register was OK.
 *   HAL_OK when all were good.
 */
static DSTATUS s25fl_read_register (const s25fl_io_t* self, const s25fl_reg_t reg, s25fl_reg_val_t * reg_val)
{
	DSTATUS res = HAL_OK;
    s25fl_msg_t  read_reg_cmd = simple_cmd_s(JEDEC_RDSR1, 0, 0);;

    simple_cmd_c(JEDEC_WREN, 0, 0, NULL, read_reg_cmd);
    res |= _send_command(self, &read_reg_cmd);

    if(res == HAL_OK)
    {
		switch( reg )
		{
			case s25fl_SR1:
			{
				simple_cmd_c(JEDEC_RDSR1, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			case s25fl_SR2:
			{
				simple_cmd_c(JEDEC_RDSR2, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			case s25fl_CR:
			{
				simple_cmd_c(JEDEC_RDCR, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			case s25fl_BR:
			{
				simple_cmd_c(JEDEC_BRRD, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			case s25fl_ECC:
			{
				simple_cmd_c(JEDEC_ECCRD, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			case s25fl_ASP:
			{
				simple_cmd_c(JEDEC_ASPRD, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			case s25fl_AB:
			{
				simple_cmd_c(JEDEC_ABRD, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			case s25fl_ID:
			{
				simple_cmd_c(JEDEC_RDID, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			case s25fl_EMS:
			{
				simple_cmd_c(JEDEC_REMS, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			case s25fl_ES:
			{
				simple_cmd_c(JEDEC_RES, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			case s25fl_DLP:
			{
				simple_cmd_c(JEDEC_DLPRD, 0, 0, reg_val, read_reg_cmd);
				break;
			}
			default:
			{
				/* register does not exist */
				return 0xFF;
			}
		}

		res |= _send_command(self, &read_reg_cmd);

		if(reg == s25fl_ASP)
		{
			uint8_t temp;
			SWAP_VALUES(reg_val[0], reg_val[1], temp);
		}
    }

    return res;
}

/**
 * @brief reads the OTP register file from FLASH.
 * @param self
 * @param result the OTP value
 */
static DSTATUS _read_OTP(const s25fl_io_t* self, uint8_t * result)
{
	DSTATUS res = HAL_OK;
    s25fl_msg_t  read_OTP_cmd;

    simple_cmd_c(JEDEC_WREN, 0, 0, NULL, read_OTP_cmd);
    res = _send_command(self, &read_OTP_cmd);

    if(res == HAL_OK)
    {
    	simple_cmd_c(JEDEC_OTPR, 0, 0, result, read_OTP_cmd);
    	res = _send_command(self, &read_OTP_cmd);
    }

    return res;
}

/**
 * @brief writes a 8bit value to a specified register.
 * @param reg register to write
 * @param reg_val value to put into
 */
static DSTATUS s25fl_write_register (const s25fl_io_t* self, const s25fl_reg_t reg, const s25fl_reg_val_t reg_val)
{
    DSTATUS res = 0x00;
    s25fl_msg_t cmd;
    s25fl_reg_val_t reg_SR1, reg_CR;

    self->read_register(self, s25fl_SR1, &reg_SR1);
    self->read_register(self, s25fl_CR, &reg_CR);

    /* send write enable command */
    simple_cmd_c(JEDEC_WREN, 0, 0, NULL, cmd);
	res = _send_command(self, &cmd);

    /* wait for WEL in SR1 to verify that write is enabled */
	res = _send_command(self, &WAIT_WEL_BIT);

    switch( reg )
    {
        case s25fl_SR1:
        {
        	reg_SR1 = reg_val;
            simple_cmd_c(JEDEC_WRR, 0, 0, NULL, cmd);
            cmd.sys_command.writearr[1] = reg_SR1;
            cmd.sys_command.writearr[2] = reg_CR;
        	break;
        }
        case s25fl_CR:
        {
        	reg_CR = reg_val;
            simple_cmd_c(JEDEC_WRR, 0, 0, NULL, cmd);
            cmd.sys_command.writearr[1] = reg_SR1;
            cmd.sys_command.writearr[2] = reg_CR;
            break;
        }
        case s25fl_BR:
        {
            simple_cmd_c(JEDEC_WRR, 0, 0, NULL, cmd);
            cmd.sys_command.writearr[1] = reg_val;
            break;
        }
        case s25fl_SR2:
        {

        }
        default:
        {
            /* register write is not supported or
               register does not exist */
        	return 0xFF;
        }
    }

    res = _send_command(self, &cmd);

    /* send write disable command */
    simple_cmd_c(JEDEC_WRDI, 0, 0, NULL, cmd);
	res |= _send_command(self, &cmd);

	return res;
}

/**
 * @brief gets full flash status from its registers
 * @param self
 * @param s25fl_status The status to which to return all the data.
 * @note The status is only from the selected flash
 */
static DSTATUS s25fl_get_status(const s25fl_io_t* self, s25fl_status_t * s25fl_status)
{
	DSTATUS res = HAL_OK;

	res |= s25fl_read_register(self, s25fl_ID, (uint8_t *)&(s25fl_status->ID));
	res |= s25fl_read_register(self, s25fl_ES, (uint8_t *)&(s25fl_status->ES));
	res |= s25fl_read_register(self, s25fl_EMS, (uint8_t *)&(s25fl_status->EMS));
	res |= s25fl_read_register(self, s25fl_SR1, (uint8_t *)&(s25fl_status->SR1));
	res |= s25fl_read_register(self, s25fl_SR2, (uint8_t *)&(s25fl_status->SR2));
	res |= s25fl_read_register(self, s25fl_CR, (uint8_t *)&(s25fl_status->CR));
	res |= s25fl_read_register(self, s25fl_ECC, (uint8_t *)&(s25fl_status->ECC));
	res |= s25fl_read_register(self, s25fl_BR, (uint8_t *)&(s25fl_status->BR));
	res |= s25fl_read_register(self, s25fl_ASP, (uint8_t *)&(s25fl_status->ASP));
	res |= s25fl_read_register(self, s25fl_AB, (uint8_t *)&(s25fl_status->AB));
	res |= s25fl_read_register(self, s25fl_DLP, (uint8_t *)&(s25fl_status->DLP));

	/* read OTP */
	res |= _read_OTP(self, s25fl_status->OTP);

	return res;
}

/**
 * @brief clears the status of the status register and sets the flash at perfect state, where it can be written or reed
 * @param self
 * @retval 0 if the operation was done without errors and write was enabled.
 * TODO: Flash could be hearing other data at the moment
 */
static DSTATUS s25fl_reset_status(const struct s25fl_io_t * self)
{
	DSTATUS res = HAL_OK;
	uint8_t buf_read[2];

	/* clear Status Register */
    res |= self->enable(self);
    res |= HAL_SPI_Transmit(self->hspi, CLSR_CMD.sys_command.writearr, CLSR_CMD.sys_command.writecnt, 100U);
    res |= self->disable(self);

	/* write optimal status register value */
    res |= self->enable(self);
    res |= HAL_SPI_Transmit(self->hspi, WRITE_PERFECT_SR_REG.sys_command.writearr, WRITE_PERFECT_SR_REG.sys_command.writecnt, 100U);
    res |= self->disable(self);

    /* WAIT WEL BIT */
    do
    {
      res |= self->enable(self);
      res |= HAL_SPI_TransmitReceive(self->hspi, WAIT_WEL_BIT.sys_command.writearr, buf_read, WAIT_WEL_BIT.sys_command.readcnt + WAIT_WEL_BIT.sys_command.writecnt, 100U);
      res |= self->disable(self);
    } while (!res && ((buf_read[WAIT_WEL_BIT.sys_command.writecnt] & WAIT_WEL_BIT.mask) != WAIT_WEL_BIT.d_val) );

    /* send write enable */
    res |= self->enable(self);
    res |= HAL_SPI_Transmit(self->hspi, WRITE_ENABLE.sys_command.writearr, WRITE_ENABLE.sys_command.writecnt, 100U);
    res |= self->disable(self);

    /* WAIT WEL BIT */
    do
    {
      res |= self->enable(self);
      res |= HAL_SPI_TransmitReceive(self->hspi, WAIT_WEL_BIT.sys_command.writearr, buf_read, WAIT_WEL_BIT.sys_command.readcnt + WAIT_WEL_BIT.sys_command.writecnt, 100U);
      res |= self->disable(self);
    } while (!res && ((buf_read[WAIT_WEL_BIT.sys_command.writecnt] & WAIT_WEL_BIT.mask) != WAIT_WEL_BIT.d_val) );


    /* send PLBWR command to clear all sector protection bits */
    res |= self->enable(self);
    res |= HAL_SPI_Transmit(self->hspi, PLBWR_CMD.sys_command.writearr, PLBWR_CMD.sys_command.writecnt, 100U);
    res |= self->disable(self);

    /* WAIT WIP BIT */
    do
    {
      res |= self->enable(self);
      res |= HAL_SPI_TransmitReceive(self->hspi, WAIT_WIP_BIT.sys_command.writearr, buf_read, WAIT_WIP_BIT.sys_command.readcnt + WAIT_WIP_BIT.sys_command.writecnt, 100U);
      res |= self->disable(self);
    } while (!res && ((buf_read[WAIT_WIP_BIT.sys_command.writecnt] & WAIT_WIP_BIT.mask) != WAIT_WIP_BIT.d_val) );

    return res;
}

/**@brief erases all flash in synchronous mode.
 * @param self
 * @param dev_num the device number of FLASH to erase
 * @retval HAL_OK if erase was of, else 0xFF
 * @note All the operations needed are done synchronously.
 * @note A bulk erase command is used
 */
static DSTATUS _erase_all_flash(s25fl_io_t * self)
{
	last_action = ACTION_FULL_ERASE;
	DSTATUS res = HAL_OK;
    int cmd = (self->queue->rear + 4) % S25FL_MAX_Q_SIZE;
    int i;
    uint8_t queue_empty = queue_is_empty(self->queue);
    uint8_t * command_buffer = &command_pool[get_command_buf_start(cmd)];
	command_buffer[0] = JEDEC_CE_C7;

	self->force_synchronous = 1;
	
	s25fl_msg_t cmds[] = {
			WRITE_PERFECT_SR_REG,
			/* send enable write command */
			WRITE_ENABLE,
			/* wait for WEL in SR1 to verify that write is enabled */
			WAIT_WEL_BIT,
			/* send erase sector command */
			full_command_s(WAIT_E_ERR_BIT.sys_command.writearr, WAIT_E_ERR_BIT.sys_command.writecnt, WAIT_E_ERR_BIT.sys_command.readarr, WAIT_E_ERR_BIT.sys_command.readcnt,\
							command_buffer, JEDEC_CE_C7_OUTSIZE, NULL, 0, S25FL_HANDLE_USER_TX, WAIT_E_ERR_BIT.mask, WAIT_E_ERR_BIT.d_val),
			/* need to disable Flash for a while after the erase command is sent */
			/* this is handled mainly by the interrupt itself */
			WAIT_WIP_BIT,
			WRITE_DISABLE,
	};

    for(i = 0; i < sizeof(cmds)/sizeof(cmds[0]); ++i)
    {
    	res |= queue_enqueue(self->queue, &cmds[i]);
    }

    if(queue_empty || self->hspi->State == HAL_SPI_STATE_READY)
    {
    	mini_dma_command();
    }

    queue_wait(self->queue, osWaitForever);

	return res;
}


void s25fl_msg_free_func(elem_addr_t addr)
{
	s25fl_msg_t *el = (s25fl_msg_t*) addr;
	memset(el, 0, sizeof(s25fl_msg_t));
}



/**
 * @brief wait until FLASH driver has no more pending request
 * @param self
 * @param timeout the amount of time to wait, until the pending requests have been executed
 * @retval if all the requests have been executed before timeout then return HAL_OK, else return 0xFF
 */
static DSTATUS s25fl_wait_till_ready(const struct s25fl_io_t* self, const uint16_t timeout)
{
	return queue_wait(self->queue, timeout);
}


DSTATUS s25fl_link_create(s25fl_io_t * s25fl_io, SPI_HandleTypeDef *hspi, GPIO_TypeDef * gpio_port, uint16_t gpio_pin, dev_id_t device_id, pqueue_t queue)
{
	DSTATUS res = HAL_OK;
	if(s25fl_io == NULL)
	{
		return 0xFF;
	}

	s25fl_io->initialized = 0;
	s25fl_io->gpio_port = GPIOB;
	s25fl_io->gpio_pin = GPIO_PIN_14;
	s25fl_io->init = s25fl_io_init_async;
	s25fl_io->reset = s25fl_reset;
	s25fl_io->get_status = s25fl_get_status;
	s25fl_io->wait_till_ready = s25fl_wait_till_ready;
	s25fl_io->write_data = s25fl_write_data;
	s25fl_io->read_data = s25fl_read_data;
	s25fl_io->erase_data = s25fl_erase_data;
	s25fl_io->read_register = s25fl_read_register;
	s25fl_io->write_register = s25fl_write_register;
	s25fl_io->enable = _enable_s25fl_io;
	s25fl_io->disable = _disable_s25fl_io;
	s25fl_io->reset_status = s25fl_reset_status;

	s25fl_io->init(s25fl_io, hspi, gpio_port, gpio_pin, device_id, queue);

	return res;
}


#endif
