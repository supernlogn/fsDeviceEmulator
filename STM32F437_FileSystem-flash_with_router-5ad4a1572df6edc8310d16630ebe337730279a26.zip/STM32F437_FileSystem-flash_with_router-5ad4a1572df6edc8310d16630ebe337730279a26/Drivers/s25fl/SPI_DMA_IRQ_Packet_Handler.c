/*
 * SPI_DMA_IRQ_Packet_Handler.c
 *
 *  Created on: 20 ���� 2017
 *      Author: ath.io
 */

#include "s25fl_io.h"
#include "s25fl_cmd.h"
#include <string.h>

#ifdef ASYNC_SUPPORT
#define mini_pause(t, time) HAL_Delay(time);

#define SPI_MSG_STATUS_RESET(node) node->status = node->init_status
#define check_read_buffer_status(buffer, val, mask, d_val) (buffer == NULL || ((val & mask) == d_val))

#define ERR_COUNTER_MAX CRITICAL_NUM_PRG_E_ERRORS
#define OK_COUNTER_MAX CRITICAL_NUM_OKS

static uint16_t err_counter = 0;
static uint16_t ok_counter = 0;

static uint8_t buf_read[10];

void SPI_DMA_IRQ_Packet_Handler(s25fl_io_t *s25fl_io)
{
  uint8_t cFlag = 1U;
  s25fl_msg_t *q_s = NULL;

  uint8_t temp_r;


  /* dma tx restart */
  while (cFlag)
  {
    cFlag = 0;
    /* wait a default period */
    //mini_pause(NULL, S25FL_TIMEOUT/2); //TODO: Ok @RCC_HCLK_DIV2

    /* Getting Next Queue Element */
    queue_front(s25fl_io->queue, (elem_addr_t*) &q_s);
    if(q_s != NULL)
    {
      switch (q_s->status)
      {
        case S25FL_HANDLE_USER_TX: // flash program or erase pass through here
        {
          ok_counter = 0;
          s25fl_io->enable(s25fl_io);
          HAL_SPI_Transmit(s25fl_io->hspi, q_s->user_data.auxiliary_buffer, q_s->user_data.auxiliary_buffer_cnt, 200U);
          HAL_SPI_Transmit_DMA(s25fl_io->hspi, q_s->user_data.buffer, q_s->user_data.buffer_cnt);
          q_s->status = S25FL_HANDLE_FLASH_PRG_ER_CMD_DATA;
          break;
        }
        case S25FL_HANDLE_USER_RX:
        {
          ok_counter = 0;
          s25fl_io->enable(s25fl_io);
          HAL_SPI_Transmit(s25fl_io->hspi, q_s->user_data.auxiliary_buffer, q_s->user_data.auxiliary_buffer_cnt, 200U);
          HAL_SPI_Receive_DMA(s25fl_io->hspi, q_s->user_data.buffer, q_s->user_data.buffer_cnt);
          q_s->status = S25FL_DONE;
          break;
        }
        case S25FL_HANDLE_FLASH_PRG_ER_CMD_DATA:
        {
          s25fl_io->enable(s25fl_io);
          HAL_SPI_TransmitReceive_DMA(s25fl_io->hspi, q_s->sys_command.writearr, buf_read, q_s->sys_command.writecnt + q_s->sys_command.readcnt); // WAIT_P_E_ERRS data
          q_s->status = S25FL_CHECK_FLASH_PRG_ER_CHECK;
          break;
        }
        case S25FL_CHECK_FLASH_PRG_ER_CHECK:
        {
          /* assign value to check */
          if(q_s->sys_command.readarr != NULL)
          {
            temp_r = buf_read[q_s->sys_command.writecnt];
            memcpy(q_s->sys_command.readarr, buf_read + q_s->sys_command.writecnt, q_s->sys_command.readcnt); //TODO: memcpy is not required this moment
          }
          else
          {
            temp_r = 0;
          }

          if(check_read_buffer_status(q_s->sys_command.readarr, temp_r, q_s->mask, q_s->d_val))
          {
            /* all ok! move forward */
            ++ok_counter;
            err_counter = 0;
            if(ok_counter >= OK_COUNTER_MAX)
            {
                queue_dequeue(s25fl_io->queue);
                if (!queue_is_empty(s25fl_io->queue))
                {
                  cFlag = 1U; // go to get a new state
                }
              ok_counter = 0;
              q_s->status = S25FL_DONE;
            }
            else
            {
                cFlag = 1U;
                q_s->status = S25FL_HANDLE_FLASH_PRG_ER_CMD_DATA; // go back to recheck
            }
          }
          else
          {
            if(temp_r & (S25FL_SR1_P_ERR | S25FL_SR1_E_ERR)) // if erase error or programming error occurred
            {
            	//mini_pause(NULL, S25FL_TIMEOUT); // TODO: Ok @RCC_HCLK_DIV2
				++err_counter;
				if(err_counter > ERR_COUNTER_MAX)
				{
				  /* Send a software restart command to flash and begin. */
				  s25fl_io->reset(s25fl_io);
				  /* wait a default period */
				  //mini_pause(NULL, S25FL_TIMEOUT);// TODO: Ok @RCC_HCLK_DIV2
				  err_counter = 0;
				}
				else
				{
				  s25fl_io->reset_status(s25fl_io);
				}
			    /* try to reprogram/re-erase the FLASH */
			    s25fl_io->reset_status(s25fl_io);
				SPI_MSG_STATUS_RESET(q_s); // reset status, to transmit data again
				cFlag = 1U;
            }
            else
            {
            	/* The flash has been doing its job, go back and check if it has finished it */
            	q_s->status = S25FL_HANDLE_FLASH_PRG_ER_CMD_DATA;
            }
            cFlag = 1U; // go to get a new state
          }
//          q_s->status = S25FL_DONE;
          break;
        }
        case S25FL_HANDLE_CMD_DATA:
        {
			if (q_s->sys_command.writearr> 0 && q_s->sys_command.writecnt > 0)
			{
			  s25fl_io->enable(s25fl_io);
			  HAL_SPI_TransmitReceive_DMA(s25fl_io->hspi, q_s->sys_command.writearr, buf_read, q_s->sys_command.writecnt + q_s->sys_command.readcnt);
			  q_s->status = S25FL_CHECK;
			}
			else if (q_s->sys_command.writecnt > 0) // write only
			{
			  s25fl_io->enable(s25fl_io);
			  HAL_SPI_Transmit_DMA(s25fl_io->hspi, q_s->sys_command.writearr, q_s->sys_command.writecnt);
			  q_s->status = S25FL_DONE;
			}
			break;
        }
        case S25FL_CHECK:
        {
			if(q_s->sys_command.readarr != NULL)
			{
			  temp_r = buf_read[q_s->sys_command.writecnt];
			  memcpy(q_s->sys_command.readarr, buf_read + q_s->sys_command.writecnt, q_s->sys_command.readcnt); //TODO: memcpy are not required this moment
			}
			else
			{
			  temp_r = 0;
			}

			if (check_read_buffer_status(q_s->sys_command.readarr, temp_r, (q_s->mask), (q_s->d_val) ))
			{
			  q_s->status = S25FL_DONE;
			  queue_dequeue(s25fl_io->queue);
			  if (!queue_is_empty(s25fl_io->queue))
			  {
				cFlag = 1U; // go to get a new state
			  }
			}
			else
			{
			  SPI_MSG_STATUS_RESET(q_s); // reset status
			  cFlag = 1U; // go to get a new state
			}
			break;
        }
        case S25FL_DONE:
        {

          queue_dequeue(s25fl_io->queue);

          if (!queue_is_empty(s25fl_io->queue))
          {
            cFlag = 1U; // go to get a new state
          }
          break;
        }
        default:
        {
          q_s->status = S25FL_ERROR_STATUS;
          break;
        }
      }
    }
  }
}
#endif
