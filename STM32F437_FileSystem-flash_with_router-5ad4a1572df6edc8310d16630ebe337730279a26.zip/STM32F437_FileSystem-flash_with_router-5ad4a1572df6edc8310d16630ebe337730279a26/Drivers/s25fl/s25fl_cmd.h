/**
 * This file contains all the commands and utilities needed for 
 * spansion S25FL flash
 */
#ifndef S25FL_COMMAND_H
#define S25FL_COMMAND_H

#define STATIC static

// OUTSIZE: The size of data + command, from MASTER
// INSIZE: The size of data after the command, from SLAVE

/* Read Electronic ID */
#define JEDEC_RDID		0x9F
#define JEDEC_RDID_OUTSIZE	1
/* INSIZE may be 0x04 for some chips*/
#define JEDEC_RDID_INSIZE	3

/* Read Electronic Manufacturer Signature */
#define JEDEC_REMS		0x90
#define JEDEC_REMS_OUTSIZE	4
#define JEDEC_REMS_INSIZE	2

/* Read Electronic Signature */
#define JEDEC_RES		0xAB
#define JEDEC_RES_OUTSIZE	4
/* INSIZE may be 0x02 for some chips*/
#define JEDEC_RES_INSIZE	1

/* Read OTP memory */
#define JEDEC_OTPR		0x4B
#define JEDEC_OTPR_OUTSIZE	4
#define JEDEC_OTPR_INSIZE	1024

/* Write Enable */
#define JEDEC_WREN		0x06
#define JEDEC_WREN_OUTSIZE	1
#define JEDEC_WREN_INSIZE	0

/* Write Disable */
#define JEDEC_WRDI		0x04
#define JEDEC_WRDI_OUTSIZE	1
#define JEDEC_WRDI_INSIZE	0

/* Read Status Register 1 */
#define JEDEC_RDSR1		0x05
#define JEDEC_RDSR1_OUTSIZE	1
#define JEDEC_RDSR1_INSIZE	1

/* Read Status Register 2 */
#define JEDEC_RDSR2		0x07
#define JEDEC_RDSR2_OUTSIZE	1
#define JEDEC_RDSR2_INSIZE	1

/* Read Configuration Register */
#define JEDEC_RDCR		0x35
#define JEDEC_RDCR_OUTSIZE	1
#define JEDEC_RDCR_INSIZE	1

/* Bank Register Read */
#define JEDEC_BRRD		0x16
#define JEDEC_BRRD_OUTSIZE	1
#define JEDEC_BRRD_INSIZE	1

/* Auto Boot Register Read */
#define JEDEC_ABRD		0x14
#define JEDEC_ABRD_OUTSIZE	1
#define JEDEC_ABRD_INSIZE	4

/* Data Learning Pattern Read */
#define JEDEC_DLPRD		0x41
#define JEDEC_DLPRD_OUTSIZE	1
#define JEDEC_DLPRD_INSIZE	2

/* Data Learning Pattern Read */
#define JEDEC_ECCRD		0x18
#define JEDEC_ECCRD_OUTSIZE	6
#define JEDEC_ECCRD_INSIZE	2

/* ASP Register Read */
#define JEDEC_ASPRD		0x2B
#define JEDEC_ASPRD_OUTSIZE	1
#define JEDEC_ASPRD_INSIZE	2

/* Clear Status Register */
#define JEDEC_CLSR		0x30
#define JEDEC_CLSR_OUTSIZE	1
#define JEDEC_CLSR_INSIZE	0

/* Bank Register Write */
#define JEDEC_BRWR		0x17
#define JEDEC_BRWR_OUTSIZE	2
#define JEDEC_BRWR_INSIZE	0

/* Write Register */
#define JEDEC_WRR       0x01
#define JEDEC_WRR_OUTSIZE   3
#define JEDEC_WRR_INSIZE   0       

/* PPB Lock Bit Write */
#define JEDEC_PLBWR		0xA6
#define JEDEC_PLBWR_OUTSIZE	1
#define JEDEC_PLBWR_INSIZE	0

/* Software Reset */
#define JEDEC_SW_RESET	0xF0
#define JEDEC_SW_RESET_OUTSIZE	1
#define JEDEC_SW_RESET_INSIZE	0
/* Register bits to be used as masks */
/*
 * !!!PLEASE NOTICE!!!
 * Note: The registers which are missing
 * from the list below, are not included
 * because all bits of those registers
 * contain the same information.
 */

/* Status Register 1 Bits */
#define S25FL_SR1_WIP	(0x01 << 0)
#define S25FL_SR1_WEL	(0x01 << 1)
#define S25FL_SR1_BP0 	(0x01 << 2)
#define S25FL_SR1_BP1 	(0x01 << 3)
#define S25FL_SR1_BP2	(0x01 << 4)
#define S25FL_SR1_E_ERR	(0x01 << 5)
#define S25FL_SR1_P_ERR	(0x01 << 6) // a.k.a. AAI
#define S25FL_SR1_SRWD	(0x01 << 7)

/* Status Register 2 Bits */
#define S25FL_SR2_ES 	(0x01 << 0)
#define S25FL_SR2_PS 	(0x01 << 1)

/* Configuration Register 1 Bits*/
#define S25FL_CR1_FREEZE	(0x01 << 0)
#define S25FL_CR1_QUAD 	(0x01 << 1)
#define S25FL_CR1_TBPARM 	(0x01 << 2)
#define S25FL_CR1_BPNV 	(0x01 << 3)
#define S25FL_CR1_TBPROT 	(0x01 << 5)
#define S25FL_CR1_LC0 	(0x01 << 6)
#define S25FL_CR1_LC1 	(0x01 << 7)

/* AutoBoot Register Bits */
#define S25FL_AB_ABE		(0x01 << 0)
#define S25FL_AB_ABSD		(0xFF << 1)
#define S25FL_AB_ABSA		(0xFFFFFC << 1)

/* Bank Register Bits */
#define S25FL_BR_BA24 	(0x01 << 0)
#define S25FL_BR_EXTADD	(0x01 << 7)

/* ECC Status Register Bits */
#define S25FL_ECCSR_ECCDI	(0x01 << 0)
#define S25FL_ECCSR_EECCD	(0x01 << 1)
#define S25FL_ECCSR_EECC 	(0x01 << 2)

/* ASP Register Bits */
#define S25FL_ASPR_PSTMLB (0x001 << 1)
#define S25FL_ASPR_PWDMLB (0x001 << 2)

/* PPB Lock Register Bits */
#define S25FL_PPBL_PPBLOCK (0x01 << 0)

/* Main memory commands */

/* Chip/Bulk Erase 0x60 is supported by Macronix/SST chips. */
#define JEDEC_CE_60		0x60
#define JEDEC_CE_60_OUTSIZE	1
#define JEDEC_CE_60_INSIZE	0

/* Chip/Bulk Erase 0xc7 is supported by SST/ST/EON/Macronix chips. */
#define JEDEC_CE_C7		0xc7
#define JEDEC_CE_C7_OUTSIZE	1
#define JEDEC_CE_C7_INSIZE	0

/* Block Erase 0xd8 is supported by EON/Macronix chips. Erase 64 kB or 256 kB.*/
#define JEDEC_BE_D8		0xD8
#define JEDEC_BE_D8_OUTSIZE	5
#define JEDEC_BE_D8_INSIZE	0

#define JEDEC_BE_DC		0xDC
#define JEDEC_BE_DC_OUTSIZE 5
#define JEDEC_BE_DC_INSIZE	0

/* Sector/Page Erase 0x20 is supported by Macronix/SST chips. Parameter 4 kB sector erase. */
#define JEDEC_P4E		0x20
#define JEDEC_SE_OUTSIZE	4 // it can also be 3
#define JEDEC_SE_INSIZE		0

/* Sector/Page Erase 0x21 is supported by Macronix/SST chips. Parameter 4 kB sector erase. */
#define JEDEC_4P4E		0x21
#define JEDEC_PE_OUTSIZE	5
#define JEDEC_PE_INSIZE		0

/* Read the memory */
#define JEDEC_READ		0x13
#define JEDEC_READ_OUTSIZE	5
#define JEDEC_READ_INSIZE -1U

#define JEDEC_FAST_READ		0x0B
#define JEDEC_FAST_READ_OUTSIZE	5
#define JEDEC_FAST_READ_INSIZE	-1U

/* Write memory byte */
#define JEDEC_BYTE_PROGRAM		0x12
#define JEDEC_BYTE_PROGRAM_OUTSIZE	5
#define JEDEC_BYTE_PROGRAM_INSIZE	0

/* Program Suspend and Resume */
#define S25FL_PROGRAM_SUSPEND	0x85
#define S25FL_PROGRAM_SUSPEND_OUTSIZE	1
#define S25FL_PROGRAM_SUSPEND_INSIZE	0

#define S25FL_PROGRAM_RESUME	0x8A
#define S25FL_PROGRAM_RESUME_OUTSIZE	1
#define S25FL_PROGRAM_RESUME_INSIZE	0

/* SPI Error codes */
#define SPI_GENERIC_ERROR	-1
#define SPI_INVALID_OPCODE	-2
#define SPI_INVALID_ADDRESS	-3
#define SPI_INVALID_LENGTH	-4
#define SPI_FLASHROM_BUG	-5
#define SPI_PROGRAMMER_ERROR	-6

#endif
