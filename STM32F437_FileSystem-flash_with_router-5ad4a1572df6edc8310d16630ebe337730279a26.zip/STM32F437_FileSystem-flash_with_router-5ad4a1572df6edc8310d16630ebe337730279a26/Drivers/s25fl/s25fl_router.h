/*
 * s25fl_rotuer.h
 *
 *  Created on: 28 ���� 2017
 *      Author: ath.io
 */

#ifndef S25FL_S25FL_ROUTER_H_
#define S25FL_S25FL_ROUTER_H_

#include "s25fl_io.h"
#include <generic_queue.h>
#include "s25fl_conf.h"

typedef struct s25fl_router_t
{
	uint8_t is_initialized;
	s25fl_io_t* s25fl_ios[MAX_NUM_FLASHES];
	dev_id_t active_device;
	uint16_t num_devs;
	DSTATUS (*select_device) (struct s25fl_router_t *self, dev_id_t dev_id_num);
	DSTATUS (*register_device) (struct s25fl_router_t * self, s25fl_io_t * s25fl_io);
	DSTATUS (*remove_device) (struct s25fl_router_t *self, dev_t dev_id);
	pqueue_t device_queue;

} s25fl_router_t;

extern s25fl_io_t* s25fl_io;

DSTATUS s25fl_router_link_create(s25fl_router_t* s25fl_router, pqueue_t device_queue);


#endif /* S25FL_S25FL_ROUTER_H_ */
