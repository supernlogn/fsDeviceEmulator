/*
 * s25fl_conf.h
 *
 *  Created on: 28 ���� 2017
 *      Author: ath.io
 */

#ifndef S25FL_S25FL_CONF_H_
#define S25FL_S25FL_CONF_H_

#define HANDLE_FIRST_BOOT 1

#define MAX_NUM_FLASHES 2

#define ASYNC_SUPPORT 1

#define S25FL_TIMEOUT 30  // 3 cycles of 90 MHz
#define S25FL_LARGE_TIMEOUT 3000 // 300 cycles of 90 MHz

#define NUM_BLOCKS 128
#define BLOCK_SIZE (256 * 1024)
#define FLASH_SIZE (NUM_BLOCKS * BLOCK_SIZE)
#define LAST_BLOCK_ADDR ((NUM_BLOCKS - 1) * BLOCK_SIZE)
#define MAX_WRITE_SIZE 256U

#define S25FL_MAX_Q_SIZE 64

#define COMMAND_POOL_SIZE 10 * 64

/* number of critical errors in FSM */
#define CRITICAL_NUM_PRG_E_ERRORS (16U)
#define CRITICAL_NUM_OKS (15U)

#ifndef osWaitForever
#define osWaitForever	0xFFFFFFFF
#endif
#endif /* S25FL_S25FL_CONF_H_ */
