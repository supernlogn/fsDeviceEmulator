/*
 * command_pool.c
 *
 *  Created on: 15 ��� 2017
 *      Author: ath.io
 */
#include "s25fl_io.h"
#ifdef ASYNC_SUPPORT
uint8_t command_pool[COMMAND_POOL_SIZE]; // 10 Bytes per command
#endif

#if 0 // all below are rejected
#define OVERFLOW_THRESSHOLD 5

const osMutexDef_t os_mutex_def_accessMtx = { 0 };

DSTATUS q_push (struct command_pool_t* self, const data *s, const uint16_t len_data)
{
	DSTATUS res = HAL_OK;
//	osMutexWait(self->accessMtx, osWaitForever);
//	osMutexRelease(self->accessMtx);
	/* do not allow overflow */
	if(self->tail + OVERFLOW_THRESSHOLD >= S25FL_MAX_Q_SIZE)
	{
		self->tail = 0;
	}
	if(self->tail + len_data % S25FL_MAX_Q_SIZE  == self->head)
	{
		res = 0xFF; // queue is full
	}
	else
	{
		self->tail = (self->tail + len_data) % S25FL_MAX_Q_SIZE;
		memcpy(&(self->q[self->tail]), data, len_data);
	}
	return res;
}

DSTATUS q_pop (struct command_pool_t* self)
{
	DSTATUS res = HAL_OK;
//	osMutexWait(self->accessMtx, 0);
	if(self->head == self->tail)
	{
		res = 0xFF; // queue is empty
	}
	else
	{
		self->head += ;
	}
//	osMutexRelease(self->accessMtx);
	return res;
}

DSTATUS q_init (struct command_pool_t* self)
{
	/* initialize the mutexes for future use */
	self->accessMtx = osMutexCreate(&os_mutex_def_accessMtx);

	return HAL_OK;
}
command_pool_t command_pool = {
		.head = 0,
		.tail = 0,
		.q_pop = q_pop,
		.q_push = q_push,
		.q_init = q_init,

};

#endif

